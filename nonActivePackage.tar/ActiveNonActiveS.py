
# developer Farhood Moslehi
#
import os
import sys
import socket
import CommOne
import smtplib
import time



def main():

    print('Start')
    
    #CommOne.CommOne1('C:/temp/Config.ini')
    ComInstance=CommOne.CommOne1('Config.ini')
    
    if (ComInstance.IsProcessUp()):
        ComInstance.WriteIntoFile('index.html','Not active','Active')
    else:            
        ComInstance.WriteIntoFile('index.html','Active','Not active')
        
    
    Recieved_data=ComInstance.OpenSocket()
    '''
    print ('the program exiting now')
    print (Recieved_data)
    '''
    '''
    while Recieved_data.find('ok'):
        Recieved_data=ComInstance.OpenSocket()
        
    '''   
        
    
                
    return    

if __name__=='__main__':
    main()
