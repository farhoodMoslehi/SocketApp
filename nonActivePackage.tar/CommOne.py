
import sys
import os
import socket
import string
import re
import time



class CommOne1:
   
    #StrFileContent='file content'
    DataFromClient="information"
    lines=[]
    StaticLine=[]
    BufferSize=1024
    processU=''
    processState=True
    timeInterval=0

    def __init__(self, CfgFile):

        self.lines=open(CfgFile)
        
        for line in self.lines:
            self.StaticLine.append(line)
            #print (line)

        self.IpAddress=(self.StaticLine[0]).split('=')[1].strip()
        self.Port=int((self.StaticLine[1]).split('=')[1])
        self.timeInterval=int((self.StaticLine[2]).split('=')[1])
       
        #print(self.timeInterval)
        
        return

    def variableReturns(self):
        
        return self.timeInterval
    
    
    def OpenSocket(self):

        '''
        self.IpAddress=(self.StaticLine[0]).split('=')[1].strip()
        self.Port=int((self.StaticLine[1]).split('=')[1])
        '''
        s=socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
           
        s.bind(('', self.Port))
        s.listen(5)
        conn, addr = s.accept()
        print('Connection address', addr)
        print ('start the process')
        self.WriteIntoFile('index.html','Not active','Active')
        os.system('/apps/ucd/server/bin/server start')
        while 1:
            data=conn.recv(self.BufferSize)
            if not data: break
            print ('received data:', data)
            self.DataFromClient=data.decode('utf-8')
            conn.send(data)
            
        conn.close()
        
        
        
        return self.DataFromClient

    def WriteIntoFile(self,indexFileName,oldStatus, newStatus):

        #print (oldStatus,newStatus)
        f=open(indexFileName,'r')
        file=f.read()
        newData=file.replace(oldStatus,newStatus)
        f.close()

        f=open(indexFileName,'w')

        f.write(newData)
        f.close()

    
        return 
    
    def IsProcessUp(self):
    
        
        #ProcessU=subprocess.Popen("ps -ef | grep java")
        #self.processU=os.system("ps -ef|grep server | grep java")
        self.processU=os.popen("ps -ef|grep server | grep java").read() 
        #print (self.processU)
        self.processState='UDeployServer' in self.processU
        
        return self.processState
        

