# This is a TCP client application
# This is a TCP client application
import os
import sys
import socket
import subprocess
import time
import re
import fnmatch
import platform
import string



class ClientComm1:
    
    lines=[]
    CfgData=[]
    BUFFER_SIZE=512
    MESSAGE='Data from client ok'
    processU=''
    processState=True
    timeInterval=0
    
    def __init__(self, CfgFile):

       self.lines=open(CfgFile)
      

       for line in self.lines:
            self.CfgData.append(line)       

       
       self.IpAddress=(self.CfgData[0]).split('=')[1].strip()
       self.Port=int((self.CfgData[1]).split('=')[1])
       self.timeInterval=int((self.CfgData[2]).split('=')[1])
       
       #print(self.timeInterval)
       
       
    def OpenSocket(self):

        
        try:
            s=socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            s.connect((self.IpAddress, self.Port))
            
            s.send(self.MESSAGE.encode('utf-8'))
            data=s.recv(self.BUFFER_SIZE)
            #s.close()
            print ('received data', data)
        except:
            print('Either the udeploy server app has gone down or is not running and the process has been handed over to the non active server (normal hand off)')
            print('or the the non active pair to this program on the non active server is not running to accept the hand off')

        return

    def WriteIntoFile(self,indexFileName,oldStatus, newStatus):

        f=open(indexFileName,'r')
        file=f.read()
        newData=file.replace(oldStatus,newStatus)
        f.close()

        f=open(indexFileName,'w')

        f.write(newData)
        f.close()

        return 
    
    def variableReturns(self):
        
        return self.timeInterval
    
    def IsProcessUp(self):
    
        
        #ProcessU=subprocess.Popen("ps -ef | grep java")
        #self.processU=os.system("ps -ef|grep server | grep java")
        self.processU=os.popen("ps -ef|grep server | grep java").read() 
        #print (self.processU)
        self.processState='UDeployServer' in self.processU
        return self.processState
        
def main():

   
    print('start')
    #ClientObject1=ClientComm.CfgData='C:/temp/Config.ini'
    #ClientObject1.opensocket()
    Client1=ClientComm1('Config.ini')
    #Client1.OpenSocket()
    #Client1.WriteIntoFile('index.html','Non Active','Active')
    '''
    print ('the number', Client1.variableReturns())
    print ('the type   ',type(Client1.variableReturns()))
    print('time interval  ',Client1.variableReturns())
    varTimeInterval=Client1.variableReturns()
    '''
    while True:
                
        Client1.IsProcessUp()
        #time.sleep(Client1.variableReturns())
        time.sleep(Client1.variableReturns())
        '''
        print('here')
        '''
        if (Client1.IsProcessUp()):
            Client1.WriteIntoFile('index.html','Not active','Active')
        else:            
            Client1.WriteIntoFile('index.html','Active','Not active')
            Client1.OpenSocket()
            break
                
    return




if __name__=='__main__':
    main()
